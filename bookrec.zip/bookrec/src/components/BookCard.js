// ============================================================
//  BookCard.js  –  Kartu tampilan satu buku di daftar
// ============================================================
import React, { useState } from "react";
import Stars from "./Stars";
import { GENRE_COLORS, GENRE_ICONS } from "../data";

/**
 * Props:
 *  - book        : objek buku { id, title, author, genre, rating, pages, year, tags, desc }
 *  - onSelect    : fungsi dipanggil saat kartu diklik → membuka modal detail
 *  - recommended : boolean, jika true tampilkan badge "REKOMENDASI"
 */
function BookCard({ book, onSelect, recommended }) {
  const [hovered, setHovered] = useState(false);

  const accentColor = GENRE_COLORS[book.genre] || "#6366f1";
  const icon        = GENRE_ICONS[book.genre]  || "📚";

  return (
    <div
      onClick={() => onSelect(book)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background:    "#fff",
        borderRadius:  16,
        border:        `2px solid ${recommended ? "#6366f1" : hovered ? "#c7d2fe" : "#e5e7eb"}`,
        padding:       "18px 20px",
        cursor:        "pointer",
        transition:    "all 0.2s",
        transform:     hovered ? "translateY(-3px)" : "none",
        boxShadow:     hovered
                         ? "0 8px 24px rgba(99,102,241,0.12)"
                         : "0 2px 8px rgba(0,0,0,0.04)",
        position:      "relative",
      }}
    >
      {/* Badge rekomendasi */}
      {recommended && (
        <div style={{
          position:     "absolute",
          top:          12,
          right:        12,
          background:   "#6366f1",
          color:        "#fff",
          fontSize:     10,
          fontWeight:   700,
          padding:      "3px 8px",
          borderRadius: 20,
        }}>
          REKOMENDASI
        </div>
      )}

      {/* Baris atas: ikon + info singkat */}
      <div style={{ display: "flex", alignItems: "flex-start", gap: 14 }}>
        {/* Ikon genre */}
        <div style={{
          width:          48,
          height:         64,
          borderRadius:   8,
          flexShrink:     0,
          background:     `linear-gradient(135deg, ${accentColor}22, ${accentColor}55)`,
          display:        "flex",
          alignItems:     "center",
          justifyContent: "center",
          fontSize:       22,
        }}>
          {icon}
        </div>

        {/* Judul, penulis, rating, tag */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: "#111827", marginBottom: 2, lineHeight: 1.3 }}>
            {book.title}
          </div>
          <div style={{ fontSize: 12, color: "#6b7280", marginBottom: 6 }}>
            {book.author} · {book.year}
          </div>
          <Stars rating={book.rating} />
          <div style={{ marginTop: 8, display: "flex", flexWrap: "wrap", gap: 4 }}>
            {/* Badge genre */}
            <span style={{
              background:   `${accentColor}15`,
              color:        accentColor,
              fontSize:     11,
              fontWeight:   600,
              padding:      "2px 8px",
              borderRadius: 20,
            }}>
              {book.genre}
            </span>
            {/* Badge jumlah halaman */}
            <span style={{
              background:   "#f3f4f6",
              color:        "#374151",
              fontSize:     11,
              padding:      "2px 8px",
              borderRadius: 20,
            }}>
              {book.pages} hal
            </span>
          </div>
        </div>
      </div>

      {/* Deskripsi singkat */}
      <p style={{ margin: "12px 0 0", fontSize: 12, color: "#6b7280", lineHeight: 1.6 }}>
        {book.desc}
      </p>
    </div>
  );
}

export default BookCard;
