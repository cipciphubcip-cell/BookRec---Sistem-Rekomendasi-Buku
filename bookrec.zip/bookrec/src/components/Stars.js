// ============================================================
//  Stars.js  –  Komponen tampilan bintang rating
// ============================================================
import React from "react";

/**
 * Menampilkan bintang penuh/kosong berdasarkan nilai rating.
 * Contoh: rating 4.8 → 4 bintang penuh + 1 kosong
 */
function Stars({ rating }) {
  const full  = Math.floor(rating);   // jumlah bintang penuh
  const empty = 5 - full;             // jumlah bintang kosong

  return (
    <span style={{ color: "#f59e0b", fontSize: 14 }}>
      {"★".repeat(full)}
      {"☆".repeat(empty)}
      {/* Angka rating di samping bintang */}
      <span style={{ color: "#6b7280", marginLeft: 4, fontSize: 12 }}>
        {rating}
      </span>
    </span>
  );
}

export default Stars;
