====================================
  BookRec - Sistem Rekomendasi Buku
====================================

CARA MENJALANKAN:
─────────────────
1. Pastikan Python 3 sudah terinstal
   Cek: python --version

2. Install Flask (hanya sekali):
   pip install flask

3. Jalankan aplikasi:
   python app.py

4. Buka browser dan ketik:
   http://127.0.0.1:5000

STRUKTUR FOLDER:
─────────────────
bookrec/
├── app.py                ← Backend Python (Flask)
├── templates/
│   └── index.html        ← Frontend (HTML + CSS + JS)
└── README.txt            ← File ini

FITUR:
──────
• Beranda       : Dashboard statistik & buku top rated
• Cari Buku     : Search + filter genre + sorting
• Statistik     : Grafik Bar, Pie, Radar (Chart.js)
• Tentang       : Info aplikasi
• Tambah Buku   : Form tambah buku baru lewat API

API ENDPOINTS:
──────────────
GET  /api/books          → ambil semua buku
GET  /api/books?q=flask  → cari buku
GET  /api/books?genre=Fiksi&sort=rating → filter+sort
POST /api/books          → tambah buku baru (JSON)
GET  /api/stats          → data statistik
