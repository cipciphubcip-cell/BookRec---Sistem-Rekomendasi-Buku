from flask import Flask, render_template, request, jsonify
import json
import os

app = Flask(__name__)

# ─── DATA BUKU (disimpan di memori, bisa diganti ke database) ─────────────────
BOOKS = [
    {"id": 1, "title": "Laskar Pelangi", "author": "Andrea Hirata", "genre": "Fiksi",
     "rating": 4.8, "pages": 529, "year": 2005,
     "tags": ["inspiratif", "persahabatan", "pendidikan"],
     "desc": "Kisah 10 anak Belitung yang berjuang meraih mimpi di sekolah yang hampir roboh."},
    {"id": 2, "title": "Bumi Manusia", "author": "Pramoedya Ananta Toer", "genre": "Sejarah",
     "rating": 4.9, "pages": 535, "year": 1980,
     "tags": ["sejarah", "perjuangan", "romansa"],
     "desc": "Kisah Minke, pemuda pribumi di era kolonial yang menemukan jati diri dan cinta."},
    {"id": 3, "title": "Negeri 5 Menara", "author": "Ahmad Fuadi", "genre": "Fiksi",
     "rating": 4.7, "pages": 423, "year": 2009,
     "tags": ["inspiratif", "pesantren", "mimpi"],
     "desc": "Perjalanan spiritual enam santri dari pesantren menuju panggung dunia."},
    {"id": 4, "title": "Atomic Habits", "author": "James Clear", "genre": "Pengembangan Diri",
     "rating": 4.8, "pages": 320, "year": 2018,
     "tags": ["produktivitas", "kebiasaan", "self-help"],
     "desc": "Panduan membangun kebiasaan baik dan menghilangkan kebiasaan buruk secara ilmiah."},
    {"id": 5, "title": "Sapiens", "author": "Yuval Noah Harari", "genre": "Non-Fiksi",
     "rating": 4.6, "pages": 443, "year": 2011,
     "tags": ["sejarah", "manusia", "evolusi"],
     "desc": "Sejarah singkat umat manusia dari zaman batu hingga era modern."},
    {"id": 6, "title": "Filosofi Teras", "author": "Henry Manampiring", "genre": "Pengembangan Diri",
     "rating": 4.5, "pages": 286, "year": 2018,
     "tags": ["stoikisme", "mindfulness", "filosofi"],
     "desc": "Filsafat Yunani-Romawi kuno untuk ketenangan hidup di era modern."},
    {"id": 7, "title": "The Psychology of Money", "author": "Morgan Housel", "genre": "Keuangan",
     "rating": 4.7, "pages": 256, "year": 2020,
     "tags": ["keuangan", "investasi", "mindset"],
     "desc": "Pelajaran tentang kekayaan, keserakahan, dan kebahagiaan dari perspektif psikologi."},
    {"id": 8, "title": "Perahu Kertas", "author": "Dewi Lestari", "genre": "Romansa",
     "rating": 4.4, "pages": 444, "year": 2009,
     "tags": ["cinta", "dewasa muda", "seni"],
     "desc": "Kisah cinta Kugy dan Keenan yang terhubung melalui mimpi dan kreativitas."},
    {"id": 9, "title": "Rich Dad Poor Dad", "author": "Robert Kiyosaki", "genre": "Keuangan",
     "rating": 4.3, "pages": 207, "year": 1997,
     "tags": ["keuangan", "investasi", "mindset"],
     "desc": "Pelajaran finansial dari dua ayah dengan filosofi uang yang berbeda."},
    {"id": 10, "title": "Dune", "author": "Frank Herbert", "genre": "Fiksi Sains",
     "rating": 4.8, "pages": 412, "year": 1965,
     "tags": ["sci-fi", "petualangan", "politik"],
     "desc": "Epik fiksi sains di planet gurun Arrakis tentang kekuasaan, agama, dan ekologi."},
    {"id": 11, "title": "Deep Work", "author": "Cal Newport", "genre": "Pengembangan Diri",
     "rating": 4.6, "pages": 304, "year": 2016,
     "tags": ["produktivitas", "fokus", "karir"],
     "desc": "Kemampuan untuk fokus tanpa gangguan pada tugas yang menuntut kognitif tinggi."},
    {"id": 12, "title": "Pulang", "author": "Tere Liye", "genre": "Thriller",
     "rating": 4.5, "pages": 400, "year": 2015,
     "tags": ["aksi", "keluarga", "misteri"],
     "desc": "Thriller tentang dunia bayangan yang tersembunyi di balik peradaban manusia."},
]

# ─── ROUTES ───────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/books", methods=["GET"])
def get_books():
    """Ambil semua buku, bisa difilter & dicari via query parameter."""
    books = BOOKS.copy()
    q      = request.args.get("q", "").lower()
    genre  = request.args.get("genre", "Semua")
    sort   = request.args.get("sort", "rating")

    if genre != "Semua":
        books = [b for b in books if b["genre"] == genre]
    if q:
        books = [b for b in books if
                 q in b["title"].lower() or
                 q in b["author"].lower() or
                 any(q in t for t in b["tags"])]
    if sort == "rating":
        books.sort(key=lambda b: b["rating"], reverse=True)
    elif sort == "tahun":
        books.sort(key=lambda b: b["year"], reverse=True)
    elif sort == "halaman":
        books.sort(key=lambda b: b["pages"], reverse=True)
    elif sort == "judul":
        books.sort(key=lambda b: b["title"])

    return jsonify(books)

@app.route("/api/books", methods=["POST"])
def add_book():
    """Tambah buku baru."""
    data = request.get_json()
    required = ["title", "author", "genre", "rating", "pages", "year", "desc"]
    for field in required:
        if not data.get(field):
            return jsonify({"error": f"Field '{field}' wajib diisi."}), 400
    try:
        rating = float(data["rating"])
        pages  = int(data["pages"])
        year   = int(data["year"])
        if not (1.0 <= rating <= 5.0):
            return jsonify({"error": "Rating harus antara 1.0 – 5.0"}), 400
        if pages < 1:
            return jsonify({"error": "Halaman harus lebih dari 0"}), 400
    except ValueError:
        return jsonify({"error": "Rating, halaman, dan tahun harus berupa angka."}), 400

    new_id = max(b["id"] for b in BOOKS) + 1 if BOOKS else 1
    tags   = [t.strip() for t in data.get("tags", "").split(",") if t.strip()]
    book   = {
        "id": new_id, "title": data["title"], "author": data["author"],
        "genre": data["genre"], "rating": round(rating, 1),
        "pages": pages, "year": year, "tags": tags, "desc": data["desc"],
    }
    BOOKS.append(book)
    return jsonify(book), 201

@app.route("/api/stats")
def stats():
    """Data statistik untuk grafik."""
    genre_count = {}
    rating_dist = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
    for b in BOOKS:
        genre_count[b["genre"]] = genre_count.get(b["genre"], 0) + 1
        rating_dist[int(b["rating"])] += 1

    top5 = sorted(BOOKS, key=lambda b: b["rating"], reverse=True)[:5]
    avg  = round(sum(b["rating"] for b in BOOKS) / len(BOOKS), 2) if BOOKS else 0

    return jsonify({
        "total": len(BOOKS),
        "avg_rating": avg,
        "genre_count": genre_count,
        "rating_dist": rating_dist,
        "top5": top5,
        "total_pages": sum(b["pages"] for b in BOOKS),
        "total_genres": len(genre_count),
    })

if __name__ == "__main__":
    print("=" * 50)
    print("  BookRec - Sistem Rekomendasi Buku")
    print("  Buka browser: http://127.0.0.1:5000")
    print("=" * 50)
    app.run(debug=True)
